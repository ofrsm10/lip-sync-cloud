import json
import requests
from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup
import boto3
import random
import logging

global s3
global dynamodb
global chat_table
global word_table

# STATES
SET = 'SET'
INITIALIZE = 'INITIALIZE'
AGE = 'AGE'
GENDER = 'GENDER'
EXPLAIN = 'EXPLAIN'
FIRST_IMAGE = 'FIRST_IMAGE'
SECOND_IMAGE = 'SECOND_IMAGE'
FIRST_VIDEO = 'FIRST_VIDEO'
SECOND_VIDEO = 'SECOND_VIDEO'
FINISH = 'FINISH'

# BUTTONS
OK = 'Ok'
NO = "Maybe later"
MALE = 'MALE'
FEMALE = "Female"
SEND_FIRST = "Send first image"
SEND_SECOND = "Send second image"
RESTART = "A fresh start"
SEND_VIDEO = "Send a video"
DONE = "No, I'm done"

# REFERENCES
CHAT_TABLE = 'ChatTable'
WORD_TABLE = "WORDS_TABLE"
TOKEN = '5900828587:AAFQa-8sbbSPn9DDnQDr8P1VpZMVnqwEVZk'
S3_BUCKET_NAME = 'lipsync'
WEBHOOK_URL = 'https://a7phgzvzge.execute-api.eu-north-1.amazonaws.com/lipsync_bot_192837465'

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
chat_table = dynamodb.Table(CHAT_TABLE)
word_table = dynamodb.Table(WORD_TABLE)


def set_webhook():
    url = f"https://api.telegram.org/bot{TOKEN}/setWebhook"
    payload = {
        "url": WEBHOOK_URL
    }
    response = requests.post(url, data=payload)
    return response.json()


# Delete the webhook
def delete_webhook():
    url = f"https://api.telegram.org/bot{TOKEN}/deleteWebhook"
    response = requests.get(url)
    return response.json()


def get_all_updates():
    url = f"https://api.telegram.org/bot{TOKEN}/getUpdates"
    response = requests.get(url)
    data = response.json()

    if data["ok"]:
        updates = data["result"]
        return updates
    else:
        return []


def log_message(message):
    # Create a logger object
    logger = logging.getLogger()

    # Set the logging level. It can be INFO, DEBUG, ERROR, etc.
    logger.setLevel(logging.DEBUG)

    # Log the message
    logger.info(message)


def get_word_with_count_zero():
    response = word_table.scan(FilterExpression='word_count = :count', ExpressionAttributeValues={':count': 0})
    items = response.get('Items', [])
    if items:
        return items[0]['word']
    else:
        return None


def get_word_with_count_below_four():
    response = word_table.scan(FilterExpression='word_count < :count', ExpressionAttributeValues={':count': 4})
    items = response.get('Items', [])
    if items:
        return items[0]['word']
    else:
        return None


def update_word_count(word):
    response = word_table.update_item(
        Key={'word': word},
        UpdateExpression='SET word_count = word_count + :val',
        ExpressionAttributeValues={':val': 1},
        ReturnValues='UPDATED_NEW'
    )
    updated_count = response.get('Attributes', {}).get('word_count')
    return updated_count


def delete_word(word):
    log_message(f"deleting {word} from words count")

    word_table.delete_item(Key={'word': word})


def add_word(word):
    word_table.put_item(Item={'word': word, 'word_count': 0})


def get_conversation_state(user_name):
    if user_name is not None:
        response = chat_table.get_item(Key={'user_name': user_name})
        item = response.get('Item')
        if item:
            return item.get('conversation_state')
        else:
            log_message(f"Chat Table: Didn't find item for {user_name}")
    else:
        log_message(f"Weird..")
        log_message("Didn't get user_name..")
    raise Exception



def get_conversation_id(user_name):
    response = chat_table.get_item(Key={'user_name': user_name})
    item = response.get('Item')
    if item:
        return item.get('id')
    else:
        return None


def get_conversation_age(user_name):
    response = chat_table.get_item(Key={'user_name': user_name})
    item = response.get('Item')
    if item:
        return item.get('age')
    else:
        return None


def get_conversation_gender(user_name):
    response = chat_table.get_item(Key={'user_name': user_name})
    item = response.get('Item')
    if item:
        return item.get('gender')
    else:
        return None


def get_words(user_name):
    response = chat_table.get_item(Key={'user_name': user_name})
    item = response.get('Item')
    if item:
        return item.get('words', [])
    else:
        return []


def update_age(user_name, age):
    response = chat_table.update_item(
        Key={'user_name': user_name},
        UpdateExpression='SET age = :age',
        ExpressionAttributeValues={':age': age},
        ReturnValues='UPDATED_NEW'
    )
    # updated_age = response.get('Attributes', {}).get('age')
    # return updated_age


def update_gender(user_name, gender):
    response = chat_table.update_item(
        Key={'user_name': user_name},
        UpdateExpression='SET gender = :gender',
        ExpressionAttributeValues={':gender': gender},
        ReturnValues='UPDATED_NEW'
    )
    # updated_gender = response.get('Attributes', {}).get('gender')
    # return updated_gender


def add_word(user_name, word):
    response = word_table.update_item(
        Key={'user_name': user_name},
        UpdateExpression='SET #w = list_append(if_not_exists(#w, :empty_list), :word)',
        ExpressionAttributeNames={'#w': 'words'},
        ExpressionAttributeValues={':empty_list': [], ':word': [word]},
        ReturnValues='UPDATED_NEW'
    )
    # updated_words = response.get('Attributes', {}).get('words')
    # return updated_words


def delete_conversation_data(user_name):
    log_message("Deleting session's data")

    response = chat_table.delete_item(Key={'user_name': user_name})
    return response


def send_initial_message(chat_id):
    message_text = "Welcome! by clicking this you give your concent to bla bla bla"

    keyboard = [[InlineKeyboardButton("Ok", callback_data=OK)]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    send_message(chat_id=chat_id, text=message_text, reply_markup=reply_markup)


def send_age_message(chat_id):
    message_text = "What is your age?"
    send_message(chat_id=chat_id, text=message_text)


def send_gender_menu(chat_id):
    message_text = "What is your gender?"
    button_option_a = InlineKeyboardButton("Male", callback_data=MALE)
    button_option_b = InlineKeyboardButton("Female", callback_data=FEMALE)
    keyboard = [[button_option_a], [button_option_b]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    send_message(chat_id=chat_id, text=message_text, reply_markup=reply_markup)


def send_first_image_menu(chat_id):
    send_message(chat_id=chat_id, text="explaining about the next step")
    button_option_a = [InlineKeyboardButton(SEND_FIRST, callback_data=SEND_FIRST)]
    keyboard = [button_option_a]
    reply_markup = InlineKeyboardMarkup(keyboard)
    send_message(chat_id=chat_id, reply_markup=reply_markup)


def send_second_image_menu(chat_id):
    button_option_a = [InlineKeyboardButton(SEND_SECOND, callback_data=SEND_SECOND)]
    keyboard = [button_option_a]
    reply_markup = InlineKeyboardMarkup(keyboard)
    send_message(chat_id=chat_id, reply_markup=reply_markup)


def send_video_menu(chat_id):
    keyboard = [[InlineKeyboardButton(SEND_VIDEO, callback_data=SEND_VIDEO)],
                [InlineKeyboardButton(RESTART, callback_data=RESTART)]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    send_message(chat_id=chat_id, reply_markup=reply_markup)


def send_second_video_menu(chat_id):
    send_message(chat_id=chat_id, text="want to send another video?.")
    keyboard = [[InlineKeyboardButton(SEND_VIDEO, callback_data=SEND_VIDEO)],
                [InlineKeyboardButton(RESTART, callback_data=RESTART)],
                [InlineKeyboardButton(DONE, callback_data=DONE)]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    send_message(chat_id=chat_id, reply_markup=reply_markup)


def send_default_response(chat_id):
    send_message(chat_id=chat_id, text="I'm sorry, I didn't understand that.")


def get_file_url(file_id):
    # Call Telegram Bot API's getFile method to retrieve the file's URL
    response = requests.get(f"https://api.telegram.org/bot{TOKEN}/getFile?file_id={file_id}")
    response_json = response.json()
    file_path = response_json['result']['file_path']
    file_url = f"https://api.telegram.org/file/bot{TOKEN}/{file_path}"
    return file_url


def send_message(chat_id, text=None, reply_markup=None):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    payload = {
        "chat_id": chat_id,
    }
    if text is not None:
        payload["text"] = text

    if reply_markup is not None:
        payload["reply_markup"] = json.dumps(reply_markup)

    response = requests.post(url, data=payload)
    return response.json()


def send_image(chat_id, image_url):
    url = f"https://api.telegram.org/bot{TOKEN}/sendPhoto"
    payload = {
        "chat_id": chat_id,
        "photo": image_url
    }
    response = requests.post(url, data=payload)
    return response.json()


def send_video(chat_id, video_url):
    url = f"https://api.telegram.org/bot{TOKEN}/sendPhoto"
    payload = {
        "chat_id": chat_id,
        "photo": video_url
    }
    response = requests.post(url, data=payload)
    return response.json()


class Session:

    def __init__(self, event):

        self.chat, self.username, self.state = get_user_info(event)

        if self.state in [None, SET, FINISH, RESTART]:
            log_message("Starting a new Session!")
            self.id = str(random.randint(100, 999))

            response = chat_table.update_item(
                Key={'user_name': self.username},
                UpdateExpression='SET age = :age, gender = :gender, words = :words, conversation_state = :state, '
                                 'session_id =:id',
                ExpressionAttributeValues={':age': '0', ':gender': 'none', ':words': [], ':state': SET,
                                           ':session_id': self.id},
                ReturnValues='UPDATED_NEW'
            )
            updated_state = response.get('Attributes', {}).get('conversation_state')
            log_message(f"Session is set to go..")

    def handle_body(self, body):

        if 'message' in body:

            message = body['message']
            text = message.get('text')
            image_file_id = message.get('photo')[-1].get('file_id') if 'photo' in message else None
            video_file_id = message.get('video').get('file_id') if 'video' in message else None

            # Process the message, image, or video data
            if text:
                # Handle text message
                self.handle_message(text)

            if image_file_id:
                # Handle image
                self.handle_image(image_file_id)

            if video_file_id:
                # Handle video
                self.handle_video(video_file_id)

        elif 'callback_query' in body:
            callback_query = body['callback_query']
            data = callback_query['data']
            self.handle_callback_query(data)

    def update_state(self, new_state):
        log_message(f"Updating state from {self.state} to {new_state}")

        response = chat_table.update_item(
            Key={'user_name': self.username},
            UpdateExpression='SET conversation_state = :state',
            ExpressionAttributeValues={':state': new_state},
            ReturnValues='UPDATED_NEW'
        )
        updated_state = response.get('Attributes', {}).get('conversation_state')
        log_message(f"Entering: {updated_state}")

    def handle_image(self, image_file_id):
        log_message(f"incoming image!")
        if self.state not in [SEND_FIRST, SEND_SECOND]:
            message_text = "not the time to send an image," \
                           "please follow the steps in their order"
            send_message(chat_id=self.id, text=message_text)
            return
        image_url = get_file_url(image_file_id)
        response = requests.get(image_url, stream=True)

        if self.state == FIRST_IMAGE:

            s3_folder_name = get_conversation_age(self.username)
            s3_key = f'{get_conversation_id(self.username)}/{s3_folder_name}/{self.username}.jpg'
            s3.upload_fileobj(response.raw, S3_BUCKET_NAME, s3_key)
            # handle first
            send_message(chat_id=self.id, text='got your first image! thanks!')
            self.update_state(SECOND_IMAGE)
            send_second_image_menu(self.id)

        elif self.state == SECOND_IMAGE:
            # handle second
            s3_folder_name = get_conversation_gender(self.username)
            s3_key = f'{get_conversation_id(self.username)}/{s3_folder_name}/{self.username}.jpg'
            s3.upload_fileobj(response.raw, S3_BUCKET_NAME, s3_key)

            message_text = "got your second image! thanks!\n" \
                           "choosing a word for you to record"
            send_message(chat_id=self.id, text=message_text)
            self.update_state(FIRST_VIDEO)
            send_video_menu(self.id)
        else:
            message_text = "not the time to send an image," \
                           "please follow the steps in their order"
            send_message(chat_id=self.id, text=message_text)

    def handle_video(self, video_file_id):
        log_message(f"incoming video!")
        if self.state is not SEND_VIDEO:
            message_text = "not the time to send a video," \
                           "please follow the steps in their order"
            send_message(chat_id=self.id, text=message_text)
            return

        word = get_words(self.username)[-1]

        video_url = get_file_url(video_file_id)

        response = requests.get(video_url, stream=True)
        s3_key = f'{get_conversation_id(self.username)}/{word}/{self.username}.mp4'
        s3.upload_fileobj(response.raw, S3_BUCKET_NAME, s3_key)

        send_message(chat_id=self.id, text='got your video! thanks!')
        send_second_video_menu(self.id)

    def handle_message(self, message_text):
        log_message(f"Incoming text message!")

        if self.state in [None, SET, FINISH, RESTART]:
            send_initial_message(self.id)
        elif self.state == AGE:
            if message_text.isdigit():
                update_age(self.username, int(message_text))
                send_gender_menu(self.id)
                self.update_state(GENDER)
            else:
                send_default_response(self.id)
        else:
            message_text = "not the time to send a text message," \
                           "please follow the steps in their order"
            send_message(chat_id=self.id, text=message_text)

    def handle_callback_query(self, callback_data):
        log_message(f"incoming callback query from {self.username}, state = {self.state}")

        if callback_data == OK:
            send_message(chat_id=self.chat, text="What is your age?")
            self.update_state(AGE)

        elif callback_data == NO:
            send_message(chat_id=self, text="sure,let's continue..")
            send_age_message(self)
            self.update_state(AGE)

        elif (callback_data == MALE) or (callback_data == FEMALE):
            update_gender(self.username, callback_data)
            self.update_state(EXPLAIN)
            send_first_image_menu(self.chat)

        elif callback_data == SEND_FIRST:
            send_message(chat_id=self.chat, text="this is how to take the FIRST image (Teeth)")
            self.update_state(FIRST_IMAGE)

        elif callback_data == SEND_SECOND:
            send_message(chat_id=self.chat, text="this is how to take the second image (tongue)")
            self.update_state(SECOND_IMAGE)

        elif callback_data == SEND_VIDEO:
            word = get_word_with_count_below_four()

            message_text = f"i chose you to record the word: {word}.\n" \
                           f"please record yourself saying the word: {word} about 5-10 times.\n" \
                           f"take breaks of at least a second.\n" \
                           f"take this video as an example and please follow the points I mentioned :)"
            send_message(chat_id=self.chat, text=message_text)

            if self.state == SECOND_IMAGE:
                self.update_state(FIRST_VIDEO)
            else:
                self.update_state(SECOND_VIDEO)

        elif callback_data == RESTART:
            send_message(chat_id=self.chat, text="Starting fresh")
            self.update_state(SET)
            send_initial_message(self.username)
        elif callback_data == DONE:
            self.update_state(FINISH)
            send_message(chat_id=self.chat, text="Thank you for participating!")
            delete_conversation_data(self.username)


def get_user_info(body):
    if 'message' in body:
        chat_id = body['message']['chat']['id']
        user_name = body['message']['from']['username']
    elif 'callback_query' in body:
        chat_id = body['callback_query']['message']['chat']['id']
        user_name = body['callback_query']['from']['username']
    else:
        raise Exception
    return chat_id, user_name, get_conversation_state(user_name)


def lambda_handler(event, context):
    log_message("incoming event!")

    # log_message(str(event))
    # delete_webhook()
    # updates = get_all_updates()
    # for update in updates:

    try:
        session = Session(event)
        log_message(f"user_name: {session.username}  state: {session.state}  session_id: {session.id}")
        session.handle_body(event)

    except Exception as e:
        log_message(e)
    finally:
        # set_webhook()
        return {
            "statusCode": 200
        }
